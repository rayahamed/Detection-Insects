# detection insect2 > original_row_images
https://universe.roboflow.com/raya-boet1/detection-insect2

Provided by a Roboflow user
License: Public Domain

